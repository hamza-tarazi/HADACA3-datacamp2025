def program(mix=None, ref=None, **kwargs):
    ##
    ## YOUR CODE BEGINS HERE
    ##
    
    # Import required packages
    required_packages = ["pandas", "numpy", "scipy"]
    install_and_import_packages(required_packages)
    
    import pandas
    import numpy
    from scipy.optimize import nnls
    
    def select_top_variable_features(ref_df, mix_df, top_n=2000):
        """Select most variable features from reference"""
        # Calculate variance across cell types for each feature
        variances = ref_df.var(axis=1)
        
        # Get top N most variable features
        top_features = variances.nlargest(min(top_n, len(variances))).index
        
        # Keep only features present in mix
        common_features = top_features.intersection(mix_df.index)
        
        return common_features
    
    def standardize_data(data_df, mean_values=None, std_values=None):
        """
        Standardize data (z-score normalization)
        If mean and std are provided, use them; otherwise calculate from data
        """
        if mean_values is None:
            mean_values = data_df.mean(axis=1)
        if std_values is None:
            std_values = data_df.std(axis=1)
            # Avoid division by zero
            std_values = std_values.replace(0, 1)
        
        # Standardize: (x - mean) / std for each row (feature)
        standardized = data_df.subtract(mean_values, axis=0).divide(std_values, axis=0)
        
        return standardized, mean_values, std_values
    
    def deconvolve_with_nnls(mix_df, ref_df, n_features=2000):
        """
        Deconvolve using NNLS with feature selection and standardization
        """
        # Select features
        selected_features = select_top_variable_features(ref_df, mix_df, top_n=n_features)
        
        # If too few features selected, use all common features
        if len(selected_features) < 100:
            selected_features = mix_df.index.intersection(ref_df.index)
        
        print(f"  Using {len(selected_features)} features")
        
        # Filter to selected features
        mix_filtered = mix_df.loc[selected_features, :]
        ref_filtered = ref_df.loc[selected_features, :]
        
        # Standardize reference
        ref_standardized, ref_mean, ref_std = standardize_data(ref_filtered)
        
        # Standardize mix using reference statistics
        mix_standardized, _, _ = standardize_data(mix_filtered, ref_mean, ref_std)
        
        # Convert to numpy arrays
        ref_array = ref_standardized.to_numpy()
        mix_array = mix_standardized.to_numpy()
        
        # Deconvolve each sample
        n_samples = mix_array.shape[1]
        n_celltypes = ref_array.shape[1]
        
        proportions = numpy.zeros((n_samples, n_celltypes))
        
        for i in range(n_samples):
            mix_sample = mix_array[:, i]
            
            try:
                # Solve: ref_array @ coef = mix_sample with coef >= 0
                coef, residual = nnls(ref_array, mix_sample)
                proportions[i, :] = coef
            except Exception as e:
                print(f"  Warning: NNLS failed for sample {i}, using uniform proportions")
                # Fallback to uniform distribution
                proportions[i, :] = 1.0 / n_celltypes
        
        # Convert to DataFrame
        prop_df = pandas.DataFrame(
            proportions,
            columns=ref_df.columns,
            index=mix_df.columns
        )
        
        # Normalize each row to sum to 1
        row_sums = prop_df.sum(axis=1)
        prop_df = prop_df.div(row_sums, axis=0)
        
        # Handle edge cases (all zeros, NaN, etc.)
        prop_df = prop_df.fillna(1.0 / n_celltypes)
        
        # Transpose to get cell types as rows, samples as columns
        return prop_df.T
    
    # ========== MAIN PROGRAM ==========
    
    # Extract methylation data
    mix_met = kwargs.get('mix_met', None)
    ref_met = kwargs.get('ref_met', None)
    
    # Deconvolve RNA
    print("Performing RNA deconvolution...")
    pred_rna = deconvolve_with_nnls(mix, ref, n_features=2000)
    
    # Deconvolve methylation if available
    if mix_met is not None and ref_met is not None:
        print("Performing methylation deconvolution...")
        pred_met = deconvolve_with_nnls(mix_met, ref_met, n_features=3000)
        
        # Ensure same samples
        common_samples = pred_rna.columns.intersection(pred_met.columns)
        
        if len(common_samples) > 0:
            pred_rna = pred_rna[common_samples]
            pred_met = pred_met[common_samples]
            
            # Combine predictions with weighted average
            print("Combining predictions...")
            weight_rna = 0.65
            weight_met = 0.35
            
            pred_combined = weight_rna * pred_rna + weight_met * pred_met
            
            # Renormalize
            col_sums = pred_combined.sum(axis=0)
            pred_combined = pred_combined.div(col_sums, axis=1)
            
            return pred_combined
        else:
            print("Warning: No common samples between RNA and methylation, using RNA only")
            return pred_rna
    else:
        print("No methylation data, using RNA only")
        return pred_rna
    
    ##
    ## YOUR CODE ENDS HERE
    ##
