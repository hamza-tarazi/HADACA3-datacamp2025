def program(mix=None, ref=None, **kwargs):
    ##
    ## YOUR CODE BEGINS HERE
    ##
    
    required_packages = ["pandas", "numpy", "scipy"]
    install_and_import_packages(required_packages)
    
    import pandas
    import numpy
    from scipy.optimize import nnls, lsq_linear
    from scipy.stats import spearmanr
    
    EPSILON = 1e-5  # Small constant to prevent exact zeros
    
    # ==================== CORE UTILITIES ====================
    
    def safe_normalize(props_df):
        """
        Safely normalize proportions, ensuring:
        1. No exact zeros (bad for Aitchison distance)
        2. Sum to 1
        3. All values in (0, 1)
        """
        # Add small epsilon to avoid zeros
        props = props_df.values + EPSILON
        
        # Normalize to sum to 1
        props = props / props.sum(axis=0, keepdims=True)
        
        # Clip to valid range (just in case)
        props = numpy.clip(props, EPSILON, 1.0 - EPSILON)
        
        # Re-normalize after clipping
        props = props / props.sum(axis=0, keepdims=True)
        
        return pandas.DataFrame(props, index=props_df.index, columns=props_df.columns)
    
    def robust_scale_features(df, ref_stats=None):
        """Robust scaling using median and MAD"""
        if ref_stats is None:
            median = df.median(axis=1)
            mad = (df.sub(median, axis=0).abs()).median(axis=1)
            mad = mad.replace(0, 1.0)
            ref_stats = (median, mad)
        else:
            median, mad = ref_stats
        
        scaled = df.sub(median, axis=0).div(mad, axis=0)
        return scaled, ref_stats
    
    # ==================== FEATURE SELECTION ====================
    
    def select_markers_strict(ref_df, mix_df, n_per_cell=180, fc_min=2.5):
        """
        Strict marker selection: highly specific to each cell type
        """
        markers = set()
        
        for cell in ref_df.columns:
            cell_expr = ref_df[cell]
            others = ref_df.drop(columns=[cell])
            
            # Fold change vs mean of others
            other_mean = others.mean(axis=1)
            fc = (cell_expr + 1) / (other_mean + 1)
            
            # Specificity vs MAX of others (stricter)
            other_max = others.max(axis=1)
            specificity = (cell_expr + 1) / (other_max + 1)
            
            # Must be highly expressed in target cell
            expr_threshold = cell_expr.quantile(0.75)
            
            # Select very specific markers
            is_marker = (
                (fc > fc_min) &
                (specificity > 2.0) &
                (cell_expr > expr_threshold) &
                (cell_expr > other_mean * 2)  # At least 2x higher than average
            )
            
            cell_markers = ref_df.index[is_marker]
            
            # Take top N by fold change
            if len(cell_markers) > 0:
                fc_sorted = fc[cell_markers].sort_values(ascending=False)
                top_n = min(n_per_cell, len(fc_sorted))
                markers.update(fc_sorted.head(top_n).index)
        
        # Keep only markers in mix
        return list(set(markers) & set(mix_df.index))
    
    def select_discriminative_features(ref_df, mix_df, n=2200):
        """
        Select features with high between/within variance ratio
        """
        # Between-group variance
        grand_mean = ref_df.mean(axis=1)
        between_var = ((ref_df.sub(grand_mean, axis=0) ** 2).sum(axis=1)) / (ref_df.shape[1] - 1)
        
        # Within-group variance
        within_var = ref_df.var(axis=1)
        
        # F-statistic
        f_stat = between_var / (within_var + 0.01)
        
        # Select top features
        top_features = f_stat.nlargest(n).index
        return list(set(top_features) & set(mix_df.index))
    
    def select_variable_features(ref_df, mix_df, n=2400):
        """Select highly variable features"""
        # Coefficient of variation
        cv = ref_df.std(axis=1) / (ref_df.mean(axis=1) + 0.1)
        
        top_features = cv.nlargest(n).index
        return list(set(top_features) & set(mix_df.index))
    
    # ==================== DECONVOLUTION METHODS ====================
    
    def deconvolve_nnls_robust(mix_df, ref_df, features, min_prop=0.001):
        """
        Robust NNLS with guaranteed non-zero proportions
        """
        common = list(set(features) & set(mix_df.index) & set(ref_df.index))
        if len(common) < 100:
            return None, 0
        
        mix_sub = mix_df.loc[common, :]
        ref_sub = ref_df.loc[common, :]
        
        # Robust scaling
        ref_scaled, stats = robust_scale_features(ref_sub)
        mix_scaled, _ = robust_scale_features(mix_sub, stats)
        
        ref_arr = ref_scaled.to_numpy()
        mix_arr = mix_scaled.to_numpy()
        
        n_samples = mix_arr.shape[1]
        n_cells = ref_arr.shape[1]
        props = numpy.zeros((n_samples, n_cells))
        qualities = []
        
        for i in range(n_samples):
            try:
                coef, residual = nnls(ref_arr, mix_arr[:, i])
                
                # Enforce minimum proportion
                coef = numpy.maximum(coef, min_prop)
                
                props[i, :] = coef
                qualities.append(1.0 / (residual + 1.0))
            except:
                props[i, :] = numpy.ones(n_cells) / n_cells
                qualities.append(0.5)
        
        # Normalize
        prop_df = pandas.DataFrame(props, columns=ref_df.columns, index=mix_df.columns)
        prop_df = safe_normalize(prop_df.T)
        
        quality = numpy.mean(qualities)
        return prop_df, quality
    
    def deconvolve_bounded_ls(mix_df, ref_df, features, min_bound=0.005, max_bound=0.95):
        """
        Bounded least squares - prevents extreme values
        """
        common = list(set(features) & set(mix_df.index) & set(ref_df.index))
        if len(common) < 100:
            return None, 0
        
        mix_sub = mix_df.loc[common, :]
        ref_sub = ref_df.loc[common, :]
        
        ref_scaled, stats = robust_scale_features(ref_sub)
        mix_scaled, _ = robust_scale_features(mix_sub, stats)
        
        ref_arr = ref_scaled.to_numpy()
        mix_arr = mix_scaled.to_numpy()
        
        n_samples = mix_arr.shape[1]
        n_cells = ref_arr.shape[1]
        props = numpy.zeros((n_samples, n_cells))
        
        # Bounds: prevent extreme values
        bounds = (
            numpy.full(n_cells, min_bound),
            numpy.full(n_cells, max_bound)
        )
        
        for i in range(n_samples):
            try:
                result = lsq_linear(ref_arr, mix_arr[:, i], bounds=bounds, method='bvls')
                props[i, :] = result.x
            except:
                props[i, :] = numpy.ones(n_cells) / n_cells
        
        prop_df = pandas.DataFrame(props, columns=ref_df.columns, index=mix_df.columns)
        prop_df = safe_normalize(prop_df.T)
        
        return prop_df, 0.75
    
    def deconvolve_iterative_refined(mix_df, ref_df, features, n_iterations=4):
        """
        Iterative refinement with outlier downweighting
        Best for noisy data
        """
        common = list(set(features) & set(mix_df.index) & set(ref_df.index))
        if len(common) < 100:
            return None, 0
        
        mix_sub = mix_df.loc[common, :]
        ref_sub = ref_df.loc[common, :]
        
        ref_scaled, stats = robust_scale_features(ref_sub)
        mix_scaled, _ = robust_scale_features(mix_sub, stats)
        
        ref_arr = ref_scaled.to_numpy()
        mix_arr = mix_scaled.to_numpy()
        
        n_samples = mix_arr.shape[1]
        n_cells = ref_arr.shape[1]
        props = numpy.zeros((n_samples, n_cells))
        
        for i in range(n_samples):
            # Initial solution
            try:
                coef, _ = nnls(ref_arr, mix_arr[:, i])
            except:
                props[i, :] = numpy.ones(n_cells) / n_cells
                continue
            
            # Iterative refinement
            for iteration in range(n_iterations):
                # Predict and calculate residuals
                predicted = ref_arr @ coef
                residuals = mix_arr[:, i] - predicted
                abs_resid = numpy.abs(residuals)
                
                # Calculate robust threshold (75th percentile)
                threshold = numpy.percentile(abs_resid, 75)
                
                # Huber-like weights
                weights = numpy.where(
                    abs_resid <= threshold,
                    1.0,
                    threshold / (abs_resid + 1e-6)
                )
                weights = numpy.clip(weights, 0.1, 1.0)
                
                # Weighted NNLS
                weighted_ref = ref_arr * weights[:, numpy.newaxis]
                weighted_mix = mix_arr[:, i] * weights
                
                try:
                    coef, _ = nnls(weighted_ref, weighted_mix)
                    # Enforce minimum
                    coef = numpy.maximum(coef, 0.001)
                except:
                    break
            
            props[i, :] = coef
        
        prop_df = pandas.DataFrame(props, columns=ref_df.columns, index=mix_df.columns)
        prop_df = safe_normalize(prop_df.T)
        
        return prop_df, 0.85
    
    # ==================== ENSEMBLE ====================
    
    def intelligent_ensemble(predictions, qualities, mix, ref):
        """
        Ensemble with quality-based weighting plus reconstruction validation
        """
        if len(predictions) == 0:
            return None
        if len(predictions) == 1:
            return predictions[0]
        
        # Calculate reconstruction quality for each method
        recon_qualities = []
        for pred in predictions:
            try:
                # Use subset of features for speed
                common = list(set(mix.index) & set(ref.index))[:1500]
                if len(common) < 500:
                    recon_qualities.append(0.5)
                    continue
                
                reconstructed = ref.loc[common, :] @ pred
                mix_sub = mix.loc[common, :]
                
                # Spearman correlation (robust to outliers)
                corrs = []
                for col in mix_sub.columns:
                    try:
                        corr = spearmanr(mix_sub[col], reconstructed[col])[0]
                        if not numpy.isnan(corr):
                            corrs.append(max(0, corr))
                    except:
                        pass
                
                recon_qual = numpy.mean(corrs) if corrs else 0.5
                recon_qualities.append(recon_qual)
            except:
                recon_qualities.append(0.5)
        
        # Combined quality: 40% method quality + 60% reconstruction quality
        combined_qualities = [
            0.4 * mq + 0.6 * rq
            for mq, rq in zip(qualities, recon_qualities)
        ]
        
        # Normalize to weights
        total = sum(combined_qualities)
        if total < 0.01:
            weights = [1.0 / len(predictions)] * len(predictions)
        else:
            weights = [q / total for q in combined_qualities]
        
        # Weighted ensemble
        ensemble = sum(w * pred for w, pred in zip(weights, predictions))
        
        # Safe normalization
        return safe_normalize(ensemble)
    
    # ==================== MAIN PROGRAM ====================
    
    mix_met = kwargs.get('mix_met', None)
    ref_met = kwargs.get('ref_met', None)
    
    print("Ultimate Optimized Deconvolution v5.0")
    print(f"Samples: {mix.shape[1]}, Features: {mix.shape[0]}")
    
    # ========== RNA DECONVOLUTION ==========
    rna_predictions = []
    rna_qualities = []
    
    if mix is not None and ref is not None:
        print("\n=== RNA Deconvolution ===")
        
        # Method 1: Strict markers + Robust NNLS
        print("1. Strict markers (high specificity)")
        markers = select_markers_strict(ref, mix, n_per_cell=180, fc_min=2.5)
        if len(markers) >= 100:
            print(f"   Found {len(markers)} markers")
            pred, qual = deconvolve_nnls_robust(mix, ref, markers, min_prop=0.001)
            if pred is not None:
                rna_predictions.append(pred)
                rna_qualities.append(qual * 1.0)
        else:
            print(f"   Only {len(markers)} markers, using relaxed criteria")
            markers = select_markers_strict(ref, mix, n_per_cell=200, fc_min=2.0)
            if len(markers) >= 100:
                pred, qual = deconvolve_nnls_robust(mix, ref, markers)
                if pred is not None:
                    rna_predictions.append(pred)
                    rna_qualities.append(qual * 0.95)
        
        # Method 2: Discriminative features + Iterative refinement
        print("2. Discriminative features + Iterative")
        disc = select_discriminative_features(ref, mix, n=2200)
        if len(disc) >= 100:
            print(f"   Using {len(disc)} discriminative features")
            pred, qual = deconvolve_iterative_refined(mix, ref, disc, n_iterations=4)
            if pred is not None:
                rna_predictions.append(pred)
                rna_qualities.append(qual * 0.95)
        
        # Method 3: Variable features + Bounded LS
        print("3. Variable features + Bounded LS")
        var_feat = select_variable_features(ref, mix, n=2400)
        if len(var_feat) >= 100:
            print(f"   Using {len(var_feat)} variable features")
            pred, qual = deconvolve_bounded_ls(mix, ref, var_feat, min_bound=0.005, max_bound=0.95)
            if pred is not None:
                rna_predictions.append(pred)
                rna_qualities.append(qual * 0.85)
        
        # Ensemble RNA
        if len(rna_predictions) > 0:
            print(f"\nEnsembling {len(rna_predictions)} RNA predictions")
            pred_rna = intelligent_ensemble(rna_predictions, rna_qualities, mix, ref)
        else:
            print("ERROR: No valid RNA predictions!")
            pred_rna = None
    else:
        pred_rna = None
    
    # ========== METHYLATION DECONVOLUTION ==========
    met_predictions = []
    met_qualities = []
    
    if mix_met is not None and ref_met is not None:
        print("\n=== Methylation Deconvolution ===")
        
        # Method 1: Strict markers
        print("1. Strict markers")
        markers_met = select_markers_strict(ref_met, mix_met, n_per_cell=220, fc_min=2.2)
        if len(markers_met) >= 100:
            print(f"   Found {len(markers_met)} markers")
            pred, qual = deconvolve_nnls_robust(mix_met, ref_met, markers_met, min_prop=0.001)
            if pred is not None:
                met_predictions.append(pred)
                met_qualities.append(qual * 1.0)
        
        # Method 2: Discriminative + Iterative
        print("2. Discriminative + Iterative")
        disc_met = select_discriminative_features(ref_met, mix_met, n=3000)
        if len(disc_met) >= 100:
            print(f"   Using {len(disc_met)} features")
            pred, qual = deconvolve_iterative_refined(mix_met, ref_met, disc_met, n_iterations=4)
            if pred is not None:
                met_predictions.append(pred)
                met_qualities.append(qual * 0.95)
        
        # Method 3: Variable + Bounded
        print("3. Variable + Bounded")
        var_met = select_variable_features(ref_met, mix_met, n=3200)
        if len(var_met) >= 100:
            print(f"   Using {len(var_met)} features")
            pred, qual = deconvolve_bounded_ls(mix_met, ref_met, var_met)
            if pred is not None:
                met_predictions.append(pred)
                met_qualities.append(qual * 0.85)
        
        # Ensemble methylation
        if len(met_predictions) > 0:
            print(f"\nEnsembling {len(met_predictions)} methylation predictions")
            pred_met = intelligent_ensemble(met_predictions, met_qualities, mix_met, ref_met)
        else:
            pred_met = None
    else:
        pred_met = None
    
    # ========== FINAL COMBINATION ==========
    if pred_rna is not None and pred_met is not None:
        print("\n=== Combining RNA + Methylation ===")
        
        # Align samples
        common_samples = pred_rna.columns.intersection(pred_met.columns)
        pred_rna = pred_rna[common_samples]
        pred_met = pred_met[common_samples]
        
        # Adaptive weighting based on number of methods
        base_rna_weight = 0.58
        base_met_weight = 0.42
        
        # Adjust based on number of successful methods
        rna_boost = (len(rna_predictions) - 1) * 0.03
        met_boost = (len(met_predictions) - 1) * 0.03
        
        rna_weight = base_rna_weight + rna_boost
        met_weight = base_met_weight + met_boost
        
        # Renormalize
        total_weight = rna_weight + met_weight
        rna_weight /= total_weight
        met_weight /= total_weight
        
        print(f"Weights: RNA={rna_weight:.3f}, Met={met_weight:.3f}")
        
        final_pred = rna_weight * pred_rna + met_weight * pred_met
        final_pred = safe_normalize(final_pred)
    elif pred_rna is not None:
        print("\n=== Using RNA only ===")
        final_pred = pred_rna
    elif pred_met is not None:
        print("\n=== Using Methylation only ===")
        final_pred = pred_met
    else:
        raise ValueError("No valid predictions generated!")
    
    # Final safety check
    final_pred = safe_normalize(final_pred)
    
    print("\n=== Final Statistics ===")
    print(f"Shape: {final_pred.shape}")
    print(f"Proportions sum range: [{final_pred.sum(axis=0).min():.6f}, {final_pred.sum(axis=0).max():.6f}]")
    print(f"Min value: {final_pred.values.min():.6f}")
    print(f"Max value: {final_pred.values.max():.6f}")
    print(f"Zero values: {(final_pred.values == 0).sum()}")
    
    return final_pred
    
    ##
    ## YOUR CODE ENDS HERE
    ##
